import React from 'react';
import { Link } from 'react-router-dom';

function Shopcategory() {
    const Shopcategory = [
        {
            name: "Appliances",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Arts And Arafts ",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Baby",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Beauty",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Books",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Collectibles",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Electronics",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Fashion",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Fashion Baby",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Fashion Boy",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Fashion Girls",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Fashion Men",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Fashion Women",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Gift Cards",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Health Care",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Home Garden",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Industrial",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Lawn And Garden",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Luggage",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Office Products",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Pet Supplies",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Sporting Goods",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Tools",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Toys",
            image: "./image/Shop-category.jpeg",
        },
        {
            name: "Wireless",
            image: "./image/Shop-category.jpeg",
        },
    ];
    
    return (
        <div className='container'>
            <div className='row'>
                {Shopcategory.map((product, index) => (
                    <div key={index} className='col-xl-2 col-md-3 col-sm-4 col-sm-6 py-3'>
                        <div className='p-3 bg-ffeb rounded-shopcatogery-col'>
                            <img className='rounded-3' src={product.image} width="100%" />
                            <div>
                                <Link to="Categories" className='text-black text-decoration-none'><h6 className='text-center text-nowrap pt-4 fw-bold font-product-name-shop-catogery text-newtheme-blue'>{product.name}</h6></Link>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default Shopcategory;
