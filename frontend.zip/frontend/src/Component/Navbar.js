import React from 'react';
import { Dropdown } from 'react-bootstrap';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'jquery/dist/jquery.min';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

function Navbar() {
    // ================Drop-down============
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };



    return (
        <div>
            <>
                {/* =============Navbaar====================*/}
                <nav className="navbar navbar-expand-md py-2 navbar-dark bgc-ffe poppins">
                    <div className="container-lg">
                        <Link to='/' className="navbar-brand d-flex">
                            <img src="./image/Nika-logo.png" width="60px" alt="Nika logo" />
                        </Link>
                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                            <span className="text-white"><i className="fa-solid fa-bars"></i></span>
                        </button>
                        <div className="bg-light-768px rounded-1 collapse navbar-collapse " id="mynavbar">
                            <ul className="navbar-nav align-items-center p-md-0 py-0 px-3 me-auto justify-content-center w-100">
                                <li className="nav-item px-xxl-4 transform-translate-menu-button transition-duration-400ms px-2 py-md-0 py-2">
                                    <Link className="line-height-18px nav-link text-center p-0 text-white poppins fw-semibold w-100" to="/">Home</Link>
                                </li>
                                <li className="nav-item px-xxl-4 transform-translate-menu-button transition-duration-400ms px-2 py-md-0 py-2">
                                    <Link className="line-height-18px nav-link text-center p-0 text-white poppins fw-semibold w-100" to="/Newarrival">New arrival</Link>
                                </li>
                                <li className="nav-item px-xxl-4 transform-translate-menu-button transition-duration-400ms px-2 py-md-0 py-2">
                                    <Link className="line-height-18px nav-link text-center p-0 text-white poppins fw-semibold w-100" to="/Categories">Trending</Link>
                                </li>
                                <li className="nav-item px-xxl-4 transform-translate-menu-button transition-duration-400ms px-2 py-md-0 py-2">
                                    <Link className="line-height-18px nav-link text-center p-0 text-white poppins fw-semibold w-100" to="/Categories">Under 99 </Link>
                                </li>
                                <li className="nav-item px-xxl-4 transform-translate-menu-button transition-duration-400ms px-2 py-md-0 py-2">
                                    <Link className="line-height-18px nav-link text-center p-0 text-white poppins fw-semibold w-100" to="">Under 199</Link>
                                </li>
                                <li className="nav-item px-xxl-4 transform-translate-menu-button transition-duration-400ms px-2 py-md-0 py-2">
                                    <Link className="line-height-18px nav-link text-center p-0 text-white poppins fw-semibold w-100" to="">Under 299</Link>
                                </li>
                                <li className="nav-item px-xxl-4 transform-translate-menu-button transition-duration-400ms px-2 py-md-0 py-2">
                                    <Link className="line-height-18px nav-link text-center p-0 text-white poppins fw-semibold w-100" to="">Under 499</Link>
                                </li>
                                <li className="nav-item px-xxl-4 px-2  transform-translate-menu-button transition-duration-400ms">
                                    <Link className="nav-link p-0 text-white poppins fw-semibold w-100" to="">
                                        <div className='position-relative-for-dropdown'>
                                            <Button className='fw-semibold text-white p-0'
                                                id="basic-button"
                                                aria-controls={open ? 'basic-menu' : undefined}
                                                aria-haspopup="true"
                                                aria-expanded={open ? 'true' : undefined}
                                                onClick={handleClick}
                                            >
                                                More<i className="ps-2 fa-solid fa-angle-down"></i>
                                            </Button>
                                            <Menu className='d-md-block manualscroll d-none poppins'
                                                id="basic-menu"
                                                anchorEl={anchorEl}
                                                open={open}
                                                onClose={handleClose}
                                                MenuListProps={{
                                                    'aria-labelledby': 'basic-button',
                                                }}
                                            >
                                                <MenuItem onClick={handleClose}>Appliances</MenuItem>
                                                <MenuItem onClick={handleClose}>Arts And Crafts</MenuItem>
                                                <MenuItem onClick={handleClose}>Baby</MenuItem>
                                                <MenuItem onClick={handleClose}>Beauty</MenuItem>
                                                <MenuItem onClick={handleClose}>Books</MenuItem>
                                                <MenuItem onClick={handleClose}>Collectibles</MenuItem>
                                                <MenuItem onClick={handleClose}>Electronics</MenuItem>
                                                <MenuItem onClick={handleClose}>Fashion</MenuItem>
                                                <MenuItem onClick={handleClose}>Fashion Baby</MenuItem>
                                                <MenuItem onClick={handleClose}>Fashion Boys</MenuItem>
                                                <MenuItem onClick={handleClose}>Fashion Girls</MenuItem>
                                                <MenuItem onClick={handleClose}>Fashion Men</MenuItem>
                                                <MenuItem onClick={handleClose}>Fashion Women</MenuItem>
                                                <MenuItem onClick={handleClose}>Gift Cards</MenuItem>
                                                <MenuItem onClick={handleClose}>Health Personal Care</MenuItem>
                                                <MenuItem onClick={handleClose}>Home Garden</MenuItem>
                                                <MenuItem onClick={handleClose}>Industrial</MenuItem>
                                                <MenuItem onClick={handleClose}>Lawn And Garden</MenuItem>
                                                <MenuItem onClick={handleClose}>Luggage</MenuItem>
                                                <MenuItem onClick={handleClose}>Office Products</MenuItem>
                                                <MenuItem onClick={handleClose}>Pet Supplies</MenuItem>
                                                <MenuItem onClick={handleClose}>Sporting Goods</MenuItem>
                                                <MenuItem onClick={handleClose}>Tools</MenuItem>
                                                <MenuItem onClick={handleClose}>Toys</MenuItem>
                                                <MenuItem onClick={handleClose}>Wireless</MenuItem>
                                            </Menu>

                                            <ul className='d-none overflow-auto rounded-2 bg-body-secondary px-0 ms-4 position-absolute-for-more border-2'>
                                                <li className='p-2'>
                                                    <Link className='fw-medium fs-14 link text-newtheme-blue'>Appliances</Link>
                                                </li>
                                                <li className='p-2'>
                                                    <Link className='fw-medium fs-14 link text-newtheme-blue'>Arts And Crafts</Link>
                                                </li>
                                                <li className='p-2'>
                                                    <Link className='fw-medium fs-14 link text-newtheme-blue'>Baby</Link>
                                                </li>
                                                <li className='p-2'>
                                                    <Link className='fw-medium fs-14 link text-newtheme-blue'>Beauty</Link>
                                                </li>
                                                <li className='p-2'>
                                                    <Link className='fw-medium fs-14 link text-newtheme-blue'>Books</Link>
                                                </li>
                                                <li className='p-2'>
                                                    <Link className='fw-medium fs-14 link text-newtheme-blue'>Collectibles</Link>
                                                </li>
                                                <li className='p-2'>
                                                    <Link className='fw-medium fs-14 link text-newtheme-blue'>Electronics</Link>
                                                </li>
                                                <li className='p-2'>
                                                    <Link className='fw-medium fs-14 link text-newtheme-blue'>Fashion</Link>
                                                </li>
                                                <li className='p-2'>
                                                    <Link className='fw-medium fs-14 link text-newtheme-blue'>Fashion Baby</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </Link>
                                </li>
                            </ul>

                            <div className="d-flex pb-md-0 pt-md-0 py-3 text-center px-lg-0 px-2 justify-content-center">
                                <li className="px-lg-3 px-2 py-1">
                                    <Link className='text-white'>
                                        <i className="fa-solid fs-5 fa-magnifying-glass"></i>
                                    </Link>
                                </li>
                                <li className="px-lg-3 px-2 py-1">
                                    <Link className='text-white'>
                                        <i className="fa-classic fs-5 fa-heart"></i>
                                    </Link>
                                </li>

                                <li className="px-lg-3 px-2 py-1">
                                    <Dropdown>
                                        <Dropdown.Toggle variant="secondary" id="dropdown-basic">
                                            <Link className='text-white'>
                                                <i className="fa fa-user fs-5"></i>
                                            </Link>
                                        </Dropdown.Toggle>

                                        <Dropdown.Menu>
                                            <Dropdown.Item href="#" className='py-2'>
                                                <Link to={"/Profile"} className='text-decoration-none text-black fw-semibold w-100'>Profile</Link>
                                            </Dropdown.Item>
                                            <Dropdown.Item href="#" className='py-2'>
                                                <Link to="/Login" className='text-decoration-none text-black fw-semibold'>Login</Link>
                                            </Dropdown.Item>
                                            <Dropdown.Item href="#" className='py-2'>
                                                <Link className='text-decoration-none text-black fw-semibold'>Logout</Link>
                                            </Dropdown.Item>
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </li>
                            </div>
                        </div>
                    </div>
                </nav>
            </>
        </div>
    )
}

export default Navbar;
