import React, { useState } from 'react';
import Rating from '@mui/material/Rating';
import Stack from '@mui/material/Stack';


function Mywhislist() {

    const [wishlist, setWishlist] = useState([
        {
            name: "Product Name 1",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Product Name 2",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Product Name 3",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Product Name 4",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        }
    ]);

    const handleDelete = (index) => {
        const newWishlist = wishlist.filter((_, i) => i !== index);
        setWishlist(newWishlist);
    };

    return (
        <div>
            <div className='container'>
                <div className='row'>
                    {wishlist.map((product, index) => (
                        <div key={index} className='col-lg-3 col-sm-6 px-xl-3 px-sm-2 py-sm-3 py-2 pb-3'>
                            <div className='bg-medium-pink rounded-3 p-3'>
                                <div className='position-relative '>
                                    <img src={product.image} width="100%" className='rounded-3 pimage-size' alt={product.name} />
                                    <div className='position-absolute-newarrival-icon' onClick={() => handleDelete(index)}>
                                        <i className="fa-regular fa-circle-xmark fs-5" style={{ cursor: 'pointer' }}></i>
                                    </div>
                                </div>
                                <div>
                                    <h6 className='m-0 fw-bold fs-14 pt-2'>{product.name}</h6>
                                    <Stack spacing={1} className='py-1'>
                                        <Rating name="size-extra-small" defaultValue={2} size="small" />
                                    </Stack>
                                    <div>
                                        <p className='text-e05 fs-6'>Free Delievery</p>
                                    </div>
                                    <div className='d-flex align-items-center'>
                                        <h6 className='mb-0 fw-bold fs-14'>{product.rs}</h6>
                                        {product.price && <div className="px-3 text-6161"><del>{product.price}</del></div>}
                                        <div className="product-discount fs-10 px-3 py-1">{product.discount}</div>
                                    </div>
                                    <div className='pt-2'>
                                        <button className='text-white fw-bold bg-da4 border-0 w-100 py-2 rounded-3'><i className="pe-2 fa-solid fa-cart-shopping"></i>Add To Cart</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

export default Mywhislist;
