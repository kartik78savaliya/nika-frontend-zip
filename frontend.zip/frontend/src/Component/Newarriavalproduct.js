import React,{useState} from 'react';
import Rating from '@mui/material/Rating';
import Stack from '@mui/material/Stack';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


function Newarriavalproduct() {
    
    const [envelopeColor, setEnvelopeColor] = useState('black');

    const handleEnvelopeClick = () => {
        setEnvelopeColor(envelopeColor === 'black' ? 'red' : 'black');
    };


    const newArrival = [
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "  ",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        }
    ];

    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        nextArrow: <SampleNextArrow />,
        prevArrow: <SamplePrevArrow />,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            }
        ]
    };

    return (
        <div>
            <div className='container'>
                <Slider {...settings}>
                    {newArrival.map((product, index) => (
                        <div key={index} className='col-lg-3 col-6 px-xl-3 px-sm-2 py-sm-3 py-2 pb-3'>
                            <div className='bg-medium-pink rounded-3 p-3'>
                                <div className='position-relative'>
                                    <img src={product.image} width="100%" className='rounded-3 pimage-size' alt={product.name} />
                                    <div className='position-absolute-newarrival-icon'>
                                        <i className="fa-regular text-light fs-4 fa-heart" style={{ color: envelopeColor }} onClick={handleEnvelopeClick}></i>
                                    </div>
                                </div>
                                <div>
                                    <h6 className='m-0 fw-bold fs-14 pt-2'>{product.name}</h6>
                                    <Stack spacing={1} className='py-1'>
                                        <Rating name="size-extra-small" defaultValue={2} size="small" />
                                    </Stack>
                                    <div className='d-flex align-items-center w-75-in-discount-sxection justify-content-between'>
                                        <h6 className='mb-0 fw-bold fs-14'>{product.rs}</h6>
                                        {product.price && <div className="px-3 text-6161"><del>{product.price}</del></div>}
                                        <div className="product-discount fs-10 px-3 py-1">{product.discount}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </Slider>
            </div>
        </div>
    )
}
function SampleNextArrow(props) {
    const { className, style, onClick } = props;
    return (
        <div
            className={`${className} custom-arrow next-arrow`}
            style={{ ...style }}
            onClick={onClick}
        >
            <button className='border-0 border-width-icon rounded-circle bg-transparent'><img src='./image/arrow2.png'></img></button>
        </div>
    );
}

function SamplePrevArrow(props) {
    const { className, style, onClick } = props;
    return (
        <div
            className={`${className} custom-arrow prev-arrow`}
            style={{ ...style }}
            onClick={onClick}
        >
            <button className='border-0 border-width-icon rounded-circle bg-transparent'><img src='./image/arrow1.png'></img></button>
        </div>
    );
}

export default Newarriavalproduct;
