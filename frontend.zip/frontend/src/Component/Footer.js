import React from "react";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <div className="bg-newtheme-blue padding-footer-top-bottom poppins">
      <div className="container">
        <div className="row max-width-footer-manual">
          <div className="col-lg-3 col-md-12 col-sm-6">
            <h4 className="fw-semibold text-white pb-sm-3 pb-2 pt-lg-0 pt-3">
              Contact Us
            </h4>
            <div>
              <div className="d-flex align-items-center py-2">
                <div className="border border-1 border-white rounded-2">
                  <i className="px-2 py-2 text-white fa-solid fa-location-dot"></i>
                </div>
                <Link className="link text-white fs-6 ps-3">
                  +91 9016031329
                </Link>
              </div>
              <div className="d-flex align-items-center py-2">
                <div className="border border-1 border-white rounded-2">
                  <i className=" p-2 text-white fa-solid fa-phone "></i>
                </div>
                <Link className="link text-white fs-6  ps-3">
                  +91 9016031329
                </Link>
              </div>

              <div className="d-flex align-items-center py-2">
                <div className="border border-1 border-white rounded-2">
                  <i className="p-2 text-white fa-solid fa-envelope"></i>
                </div>
                <Link className="link text-white fs-6  ps-3">
                  info@nika.com
                </Link>
              </div>
              <div className="d-flex align-items-center py-2">
                <div className="border border-1 border-white rounded-2">
                  <i className="p-2 text-white fa-solid fa-envelope"></i>
                </div>
                <Link className="link text-white fs-6  ps-3">nika.com</Link>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-md-4 col-sm-6">
            <h4 className="fw-semibold text-white pb-sm-3 pt-md-0 pt-3 pb-2">
              Our Products Pdf Link
            </h4>
            <ul className=" ps-0">
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Glassware Product
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Under 99 Product
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Without Price Product
                </Link>
              </li>
            </ul>
            <br></br>
            <h4 className="fw-semibold text-white pb-sm-3 pt-md-0 pt-3 pb-2">
              Quick Links
            </h4>
            <ul className=" ps-0">
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  About the Company
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Terms & Conditions
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Customer Support
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  frequently Asked Questions
                </Link>
              </li>
            </ul>
          </div>
          <div className="col-lg-3 col-md-4 col-sm-6">
            <h4 className="fw-semibold text-white pb-sm-3 pt-md-0 pt-3 pb-2">
              Service
            </h4>
            <ul className="ps-0">
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Online Selling Product
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Dropshipping
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Packaging Material
                </Link>
              </li>
            </ul>
          </div>
          <div className="col-lg-3 col-md-4 col-sm-6">
            <h4 className="fw-semibold text-white pb-sm-3 pt-md-0 pt-3 pb-2">
              My Account
            </h4>
            <ul className=" ps-0">
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Account Info
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  My account
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Order History
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  Wish List
                </Link>
              </li>
              <li className="fs-6  pb-2">
                <Link className="text-white text-decoration-none">
                  My Wallet
                </Link>
              </li>
            </ul>
            <div className="pt-3">
              <h6 className="fw-bold text-white fs-5">Follow Us</h6>
              <div className="d-flex align-items-center">
                <div className="social-icon">
                  <Link className="text-black">
                    <i className="fa-brands fa-facebook-f fs-14 p-3"></i>
                  </Link>
                </div>
                <div className="social-icon">
                  <Link className="text-black">
                    <i className="fa-brands fa-x-twitter fs-14 p-3"></i>
                  </Link>
                </div>
                <div className="social-icon">
                  <Link className="text-black">
                    <i className="fa-brands fa-instagram fs-14 p-3"></i>
                  </Link>
                </div>
                <div className="social-icon">
                  <Link className="text-black">
                    <i className="fa-brands fa-youtube fs-14 p-3"></i>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr style={{ border: "1px solid white" }} />

        <div style={{display:"flex", justifyContent:"center"}}>
          <i className="fa-regular fs-4 font-semibold text-white fa-copyright"></i>
          <h4 className="text-white fs-5">&nbsp; &nbsp;Copyright <b>NIKA ENTERPRISE</b>. All Rights Reserved.</h4>
        </div>
      </div>
    </div>
  );
}

export default Footer;
