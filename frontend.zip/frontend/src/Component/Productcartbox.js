import React, { useState } from 'react';

function Productcartbox() {
    const [cart, setCart] = useState([
        {
            name: "Product 1",
            Unitprice: "₹ 1000",
            image: "./image/productdetail.jpg"
        },
        {
            name: "Product 2",
            Unitprice: "₹ 1000",
            image: "./image/productdetail.jpg"
        },
        {
            name: "Product 3",
            Unitprice: "₹ 1000",
            image: "./image/productdetail.jpg"
        },
        {
            name: "Product 4",
            Unitprice: "₹ 1000",
            image: "./image/productdetail.jpg"
        }
    ]);

    const handleDelete = (index) => {
        const newCart = cart.filter((_, i) => i !== index);
        setCart(newCart);
    };

    return (
        <div>
            <div className='pt-sm-5 pt-4'>
                <div className='container'>
                    <div className='d-md-flex align-items-center border-bottom border-black d-none'>
                        <div className='col-6 text-end pe-md-3'>
                            <h6 className='fw-bold font-size-for-20px-in-whishlist text-newtheme-blue pe-2'>Products Name</h6>
                        </div>
                        <div className='col-6 text-start ps-md-3'>
                            <h6 className='fw-bold font-size-for-20px-in-whishlist text-2121'>Unit Price</h6>
                        </div>
                    </div>
                    {cart.map((product, index) => (
                        <div key={index}>
                            <div className='d-md-flex align-items-center py-3 border-bottom border-top border-black'>
                                <div className='col-md-6'>
                                    <div className='d-flex align-items-center w-100 justify-content-between'>
                                        <div className='col-md-7 d-flex'>
                                            <div className='d-flex align-items-center '>
                                                <div className='px-xl-4 px-2'>
                                                    <button className='bg-ffe border-0 py-2 px-md-3 px-2 rounded-3'  onClick={() => handleDelete(index)}><i className="text-e05 fa-solid fa-trash"></i></button>
                                                </div>
                                                <div className='px-md-0 px-sm-4'>
                                                    <img src={product.image} width="190px" alt='' className=' rounded-3 image-width-whishlist' />
                                                </div>
                                            </div>
                                        </div>
                                        <div className='col-md-5 text-md-center d-flex flex-column justify-content-end ps-md-0 px-sm-5 '>
                                            <p className='fw-normal  font-product-name-in-whishlist'>{product.name}</p>
                                            <div className='ps-md-3 d-md-none d-block'>
                                                <p className='fw-normal font-product-name-in-whishlist py-md-0 py-1'>{product.Unitprice}</p>
                                            </div>
                                            <div className='d-md-none d-block'>
                                                <button className='px-xl-5 px-3 py-2 rounded-3 font-add-cart-whishlist bg-da4 text-white border-0 fw-bold'><i className="pe-2 fa-solid fa-cart-shopping"></i>Add To Cart</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-md-6 d-md-block d-none'>
                                    <div className='d-flex align-items-center'>
                                        <div className='col-6 ps-3'>
                                            <p className='fw-normal  fs-5'>₹ 1000</p>
                                        </div>
                                        <div className='col-6 text-end'>
                                            <button className='px-xl-5 px-3 py-2 rounded-3 bg-da4 text-white border-0 fw-bold'><i className="pe-2 fa-solid fa-cart-shopping"></i>Add To Cart</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

export default Productcartbox;
