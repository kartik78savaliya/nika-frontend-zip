import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Layout from "./Pages/Layout";
import Home from "./Pages/Home";
import NewArrival from "./Pages/NewArrival";
import Categories from "./Pages/Categories";
import Productexplore from "./Pages/Productexplore";
import Productdetail from "./Pages/Productdetail";
import Cart from "./Pages/Cart";
import Address from "./Address";
import Payment from "./Pages/Payment";
import Whislist from "./Pages/Whislist";
import Login from "./Pages/Login";
import Signup from "./Pages/Signup";
import Profile from "./Pages/Profile";

function App() {

  return (
    <>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/Newarrival" element={<NewArrival />} />
            <Route path="/Categories" element={<Categories />} />
            <Route path="/Productexplore" element={<Productexplore />} />
            <Route path="/Productdetail" element={<Productdetail />} />
            <Route path="/Cart" element={<Cart />} />
            <Route path="/Address" element={<Address />} />
            <Route path="/Payment" element={<Payment />} />
            <Route path="/Whislist" element={<Whislist />} />
            <Route path="/Login" element={<Login />} />
            <Route path="/Signup" element={<Signup />} />
            <Route path="/Profile" element={<Profile />} />
          </Routes>
        </Layout>
      </Router>
    </>
  );
}

export default App;
