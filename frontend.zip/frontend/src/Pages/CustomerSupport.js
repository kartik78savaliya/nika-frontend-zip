import React from 'react'

const CustomerSupport = () => {
  return (
    <div>CustomerSupport</div>
  )
}

export default CustomerSupport