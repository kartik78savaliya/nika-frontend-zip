import React, { useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import {
  Navigation,
  Pagination,
  Mousewheel,
  Keyboard,
  Autoplay,
} from "swiper/modules";
import Newarriavalproduct from "../Component/Newarriavalproduct";
import Trendproduct from "../Component/trendproduct";
import Under99product from "../Component/Under99product";
import Under199product from "../Component/Under199product";
import Under299product from "../Component/Under299product";
import Under499product from "../Component/Under499product";
import Shopcategory from "../Component/Shopcategory";
import Footer from "../Component/Footer";
import { Navigate, useNavigate } from "react-router-dom";

function Home() {
  const swiperRef = useRef(null);

  const handlePaginationClick = (index) => {
    if (swiperRef.current && swiperRef.current.swiper) {
      swiperRef.current.swiper.slideTo(index);
    }
  };

  // const handleViewallClick = () => {
  //   useNavigate("/Category");
  // };

  return (
    <>
      <body>
        <main>
          {/* ==================Swipper-slider-start================= */}
          <div className="pb-md-5 pb-3">
            <Swiper
              ref={swiperRef}
              cssMode={true}
              navigation={true}
              mousewheel={true}
              keyboard={true}
              pagination={{ el: ".custom-pagination", clickable: true }}
              loop={true}
              autoplay={{
                delay: 2500, // Delay between transitions (in ms)
                disableOnInteraction: false, // Continue autoplay after user interaction
              }}
              modules={[Navigation, Pagination, Mousewheel, Keyboard, Autoplay]}
              className="mySwiper"
            >
              <SwiperSlide>
                <img
                  src="./Image/Home-slider-1.png"
                  width="100%"
                  alt="Slide 1"
                />
              </SwiperSlide>
              <SwiperSlide>
                <img
                  src="./Image/Home-slider-1.png"
                  width="100%"
                  alt="Slide 2"
                />
              </SwiperSlide>
              <SwiperSlide>
                <img
                  src="./Image/Home-slider-1.png"
                  width="100%"
                  alt="Slide 3"
                />
              </SwiperSlide>
              <SwiperSlide>
                <img
                  src="./Image/Home-slider-1.png"
                  width="100%"
                  alt="Slide 4"
                />
              </SwiperSlide>
            </Swiper>

            <div className="custom-pagination">
              <span
                onClick={() => handlePaginationClick(0)}
                className="custom-dot"
              ></span>
              <span
                onClick={() => handlePaginationClick(1)}
                className="custom-dot"
              ></span>
              <span
                onClick={() => handlePaginationClick(2)}
                className="custom-dot"
              ></span>
            </div>
          </div>
          {/* ==================Swipper-slider-end================= */}

          {/* =================Services-start================= */}
          <div className="py-md-5 py-sm-4 py-3">
            <div className="container poppins">
              <div className="row">
                <div className="col-lg-4 col-md-6 col-12 py-lg-0 py-4">
                  <div className="bg-light-pink pt-5 pb-3 px-3 rounded-4 position-relative">
                    <div className="position-absolute-for-freeshopping">
                      <img
                        className="shipping-image-size text-newtheme-blue"
                        src="./image/service-11.png"
                        width={"80px"}
                        alt=""
                      />
                    </div>
                    <div>
                      <h4 className="text-white fw-bold fs-4">Free shipping</h4>
                      <p className="fw-normal text-white">
                        Lorem Ipsum has been the industry's standard dummy text
                        ever since the 1500s, when an unknown printer took a
                        galley of.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="col-lg-4 col-md-6 col-12 py-lg-0 py-4">
                  <div className="bg-light-pink pt-5 pb-3 px-3 rounded-4 position-relative">
                    <div className="position-absolute-for-freeshopping">
                      <img
                        className="shipping-image-size"
                        src="./image/sevice-12.png"
                        width={"80px"}
                        alt=""
                      />
                    </div>
                    <div>
                      <h4 className="text-white fw-bold fs-4">Best Quality</h4>
                      <p className="fw-normal text-white">
                        Lorem Ipsum has been the industry's standard dummy text
                        ever since the 1500s, when an unknown printer took a
                        galley of.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="col-lg-4 col-md-6 col-12 py-lg-0 pt-4 pb-sm-4 pb-0">
                  <div className="bg-light-pink pt-5 pb-3 px-3 rounded-4 position-relative">
                    <div className="position-absolute-for-freeshopping">
                      <img
                        className="shipping-image-size"
                        src="./image/service-13.png"
                        width={"80px"}
                        alt=""
                      />
                    </div>
                    <div>
                      <h4 className="text-white fw-bold fs-4">
                        Customer Service
                      </h4>
                      <p className="fw-normal text-white">
                        Lorem Ipsum has been the industry's standard dummy text
                        ever since the 1500s, when an unknown printer took a
                        galley of.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* =================Services-End================= */}

          {/* ===============Shop-now-start============= */}
          <div className="poppins">
            <div className="container py-3">
              <div className="row align-items-center">
                <div className="col-md-6 py-md-0 py-2">
                  <div className="position-relative d-flex justify-content-center">
                    <img
                      src="./image/shopnow-1.jpeg"
                      width="100%"
                      alt=""
                      className="rounded-3 image-size-for-shopnow"
                    />
                    <div className="position-absolute rounded-start-bottom-5 top-0">
                      <div className="bg-light-white d-flex round-left-bottom flex-column height-300px-width440px align-items-center justify-content-center">
                        <h4 className="fs-2 fw-bold mb-0">40% Discount</h4>
                        <p className="fs-4 fw-normal py-sm-3 py-2">
                          kitchen wayfair
                        </p>
                        <div className="">
                          <button className="px-5 py-2 fw-bold bg-e05 text-white border-0 rounded-2 ">
                            Shop Now
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-md-6 py-md-0 py-2">
                  <div className="d-flex justify-content-center">
                    <img
                      src="./image/shopnow-2.jpeg"
                      alt=""
                      className="height-shopnow-2"
                      width="60%"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="container py-3">
              <div className="row align-items-center">
                <div className="col-md-6 py-md-0 py-2">
                  <div className="d-flex justify-content-center">
                    <img
                      src="./image/shopnow-2.jpeg"
                      alt=""
                      className="height-shopnow-22"
                      width="60%"
                    />
                  </div>
                </div>
                <div className="col-md-6 py-md-0 py-2">
                  <div className="position-relative d-flex justify-content-center">
                    <img
                      src="./image/shopnow-1.jpeg"
                      alt=""
                      width="100%"
                      className="rounded-3 image-size-for-shopnow"
                    />
                    <div className="position-absolute rounded-start-bottom-5 top-0">
                      <div className="bg-light-white d-flex round-left-bottom2 flex-column height-300px-width440px align-items-center justify-content-center">
                        <h4 className="fs-2 fw-bold mb-0">40% Discount</h4>
                        <p className="fs-4 fw-normal py-3">kitchen wayfair</p>
                        <div className="">
                          <button className="px-5 py-2 fw-bold bg-e05 text-white border-0 rounded-2 ">
                            Shop Now
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* ===============Shop-now-End============= */}

          {/* ===============new-arrival-products-start==============*/}
          <div className="poppins">
            <div className="pt-4 pb-sm-5 pb-3">
              <div className="pb-3">
                <div className="container">
                  <div className="row">
                    <div className="d-flex align-items-center justify-content-between">
                      <h4 className="font-size-32px-product-title text-newtheme-blue my-0">
                        New Arrival Products
                      </h4>
                      <div>
                        <button
                          className="bg-da4 product-veiwall-font-size px-2 rounded-2 border-0 text-white py-1"
                          // onClick={handleViewallClick}
                        >
                          View All
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <Newarriavalproduct />
            </div>
          </div>
          {/* ===============new-arrival-products-end==============*/}

          {/* ===============trending-products-start============== */}
          <div className="poppins">
            <div className="pt-4 pb-sm-5 pb-3">
              <div className="pb-3">
                <div className="container">
                  <div className="row">
                    <div className="d-flex align-items-center justify-content-between">
                      <h4 className="font-size-32px-product-title text-newtheme-blue my-0">
                        Trending Products
                      </h4>
                      <div>
                        <button className="bg-da4 product-veiwall-font-size px-2 rounded-2 border-0 text-white py-1">
                          View All
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <Trendproduct />
            </div>
          </div>
          {/* ===============trending-products-end============== */}

          {/* ===============under-99-products-start============== */}
          <div className="poppins">
            <div className="pt-4 pb-sm-5 pb-3">
              <div className="pb-3">
                <div className="container">
                  <div className="row">
                    <div className="d-flex align-items-center justify-content-between">
                      <h4 className="font-size-32px-product-title text-newtheme-blue my-0">
                        Under 99 Products
                      </h4>
                      <div>
                        <button className="bg-da4 product-veiwall-font-size px-2 rounded-2 border-0 text-white py-1">
                          View All
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <Under99product />
            </div>
          </div>
          {/* ===============under-99-products-end============== */}

          {/* ===============under-199-products-start============== */}
          <div className="poppins">
            <div className="pt-4 pb-sm-5 pb-3">
              <div className="pb-3">
                <div className="container">
                  <div className="row">
                    <div className="d-flex align-items-center justify-content-between">
                      <h4 className="font-size-32px-product-title text-newtheme-blue my-0">
                        Under 199 Products
                      </h4>
                      <div>
                        <button className="bg-da4 product-veiwall-font-size px-2 rounded-2 border-0 text-white py-1">
                          View All
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <Under199product />
            </div>
          </div>
          {/* ===============under-199-products-end============== */}

          {/* ===============under-299-products-start============== */}
          <div className="poppins">
            <div className="pt-4 pb-sm-5 pb-3">
              <div className="pb-3">
                <div className="container">
                  <div className="row">
                    <div className="d-flex align-items-center justify-content-between">
                      <h4 className="font-size-32px-product-title text-newtheme-blue my-0">
                        Under 299 Products
                      </h4>
                      <div>
                        <button className="bg-da4 product-veiwall-font-size px-2 rounded-2 border-0 text-white py-1">
                          View All
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <Under299product />
            </div>
          </div>
          {/* ===============under-299-products-end============== */}

          {/* ===============under-499-products-start============== */}
          <div className="poppins">
            <div className="pt-4 pb-sm-5 pb-3">
              <div className="pb-3">
                <div className="container">
                  <div className="row">
                    <div className="d-flex align-items-center justify-content-between">
                      <h4 className="font-size-32px-product-title text-newtheme-blue my-0">
                        Under 499 Products
                      </h4>
                      <div>
                        <button className="bg-da4 product-veiwall-font-size px-2 rounded-2 border-0 text-white py-1">
                          View All
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <Under499product />
            </div>
          </div>
          {/* ===============under-499-products-end============== */}

          {/* ===============Shopnow-Start============ */}
          <section>
            <div className="py-4">
              <div className="container">
                <div className="row position-relative">
                  <div className="col-md-6 col-12 d-flex justify-content-md-start justify-content-center py-md-4 py-sm-3 py-2">
                    <div>
                      <img
                        src="./image/second-shopnow.jpeg"
                        alt=""
                        className="second-shopnow-image rounded-3"
                      />
                    </div>
                  </div>

                  <div className="col-md-6 col-12 d-flex justify-content-md-end justify-content-center py-md-4 py-sm-3 py-2">
                    <div>
                      <img
                        src="./image/second-shopnow.jpeg"
                        alt=""
                        className="second-shopnow-image rounded-3"
                      />
                    </div>
                  </div>

                  <div className="col-md-6 d-md-block d-none col-12 d-flex justify-content-md-start justify-content-center py-md-4 py-sm-3 py-2">
                    <div>
                      <img
                        src="./image/second-shopnow.jpeg"
                        alt=""
                        className="second-shopnow-image rounded-3"
                      />
                    </div>
                  </div>

                  <div className="col-md-6 col-12 d-flex justify-content-md-end justify-content-center py-md-4 py-sm-3 py-2">
                    <div>
                      <img
                        src="./image/second-shopnow.jpeg"
                        alt=""
                        className="second-shopnow-image rounded-3"
                      />
                    </div>
                  </div>

                  <div className="poppins position-absulate-for-secondshopnow col-md-6 col-12 d-flex justify-content-center  py-md-4 py-sm-3 py-2">
                    <div className="bg-transparent-light pt-xl-5 pt-4 pb-xl-4 pb-3 rounded-3 px-md-5 px-4">
                      <h4 className="fw-bold fs-2 text-center">Lorem Ipsum</h4>
                      <p className="fw-normal font-size-second-shop-paradraph text-2121 pt-2">
                        Lorem Ipsum has been the industry's standard dummy text
                        ever since the 1500s, when an unknown printer took a
                        galley of type.
                      </p>
                      <div className="text-center pt-2">
                        <button className="py-2 px-5 fw-bold rounded-3 bg-e05 text-white border-0">
                          Shop Now
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {/* ===============Shopnow-End============ */}

          {/* ==============Shop-categories-start============= */}
          <div className="poppins">
            <div className="pt-sm-4 pt-3 pb-sm-5 pb-3">
              <div className="pb-sm-3 pb-2">
                <div className="container">
                  <div className="row">
                    <div className="text-center">
                      <h4 className="font-size-32px-product-title text-newtheme-blue my-0">
                        Shop Categories
                      </h4>
                    </div>
                  </div>
                </div>
              </div>
              <Shopcategory />
            </div>
          </div>
          {/* ==============Shop-categories-end============= */}

          {/* ===========Footer============== */}
          <Footer />
        </main>
      </body>
    </>
  );
}

export default Home;
