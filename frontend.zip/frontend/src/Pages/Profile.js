import React from 'react';
import { Link } from 'react-router-dom';
import Footer from '../Component/Footer';

function Profile() {

    return (
        <>
            <div className='poppins py-sm-5 py-3'>
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-4 col-md-5 pb-md-0 pb-4'>
                            <div className='border py-3 border-1 border-black rounded-3'>
                                <div className='d-flex px-3 justify-content-between align-items-center'>
                                    <div className='d-flex align-items-center'>
                                        <img src='./image/Userlogoprofile.png' width={"35px"} alt='' />
                                        <Link className='fs-4 fw-semibold text-da4 text-decoration-none ps-3'>My Profile</Link>
                                    </div>
                                </div>
                                <div className='ps-5'>
                                    <Link className='text-da4 text-decoration-none ps-5 fw-medium d-block'>My Details</Link>
                                    <Link className='text-black text-decoration-none ps-5 fw-medium d-block'>Deliver Address</Link>
                                </div>

                                <div className='px-3 pt-3 pb-2'>
                                    <img src='./image/historyorder.png' width={"35px"} alt='' />
                                    <Link className='fs-5 text-4230 ps-3 fw-semibold text-decoration-none '>History Of Orders</Link>
                                </div>
                                <div className='border-bottom border-2 border-secondary-subtle mx-3 pt-2'></div>

                                <div className='px-3 pt-3 pb-2'>
                                    <div className='py-2'>
                                        <img src='./image/Setting.png' width={"35px"} alt='' />
                                        <Link className='fs-5 text-4230 ps-3 fw-semibold text-decoration-none'>Setting</Link>
                                    </div>
                                    <div className='py-2'>
                                        <img src='./image/Notifications.png' width={"35px"} alt='' />
                                        <Link className='fs-5 text-4230 ps-3 fw-semibold text-decoration-none'>Notifications</Link>
                                    </div>
                                </div>
                                <div className='border-bottom border-2 border-secondary-subtle mx-3 pt-2'></div>

                                <div className='px-3 pt-3 pb-2'>
                                    <div className='py-2'>
                                        <img src='./image/Help.png' width={"35px"} alt='' />
                                        <Link className='fs-5 text-4230 ps-3 fw-semibold text-decoration-none'>Help</Link>
                                    </div>
                                    <div className='py-2'>
                                        <img src='./image/Logout.png' width={"35px"} alt='' />
                                        <Link className='fs-5 text-4230 ps-3 fw-semibold text-decoration-none'>Log out</Link>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className='col-lg-8 col-md-7'>
                            <div className='border p-lg-5 p-3  border-1 border-black rounded-3'>
                                <div>
                                    <div className='d-sm-flex text-center align-items-center pb-4'>
                                        <img src='./image/Profileicon.png' width={"166px"} className='Rounded-image-profile' />
                                        <div className='ps-lg-4 ps-sm-3 ps-0'>
                                            <div className='d-flex justify-content-sm-between justify-content-center pt-sm-0 pt-2'>
                                                <h6 className='fs-5 fw-bold text-4230 pe-sm-0 pe-3'>Your Name</h6>
                                                <Link className='fs-6 fw-semibold text-da4 text-decoration-none ps-sm-0 ps-4'>Edit Profile</Link>
                                            </div>
                                            <p className='fs-5 fw-normal'>LoremIpsum@gmail.com</p>
                                        </div>
                                    </div>
                                    <div>
                                        <h6 className='fw-bold fs-5'>My Data</h6>
                                        <form>
                                            <div className='py-sm-3 py-2'>
                                                <label id='Name' className='d-block fw-medium  text-4230 fs-18 pb-2'>Name</label>
                                                <input for='Name' className='rounded-3 border-1 width-height-input-profile p-3 py-sm-3 py-2 form-control' placeholder='Enter Your Name' />
                                            </div>
                                            <div className='py-sm-3 py-2'>
                                                <label className='d-block fw-medium text-4230  fs-18 pb-2'>Last Name</label>
                                                <input className='rounded-3 border-1 width-height-input-profile p-3 py-sm-3 py-2 form-control' placeholder='Enter Your Last Name' />
                                            </div>
                                            <div className='py-sm-3 py-2'>
                                                <label className='d-block fw-medium text-4230  fs-18 pb-2'>Email Address</label>
                                                <input className='rounded-3 border-1 width-height-input-profile p-3 py-sm-3 py-2 form-control' placeholder='Enter Your Email Address' />
                                            </div>
                                            <div className='py-sm-3 py-2'>
                                                <label className='d-block fw-medium text-4230  fs-18 pb-2'>Mobile Number</label>
                                                <input className='rounded-3 border-1 width-height-input-profile p-3 py-sm-3 py-2 form-control' placeholder='Enter Your Mobile Number' />
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Profile;
