import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function Login() {

    const [showPassword, setShowPassword] = useState(false);

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };


    return (
        <div className='poppins'>
            <div className='container-fluid overflow-hidden'>
                <div className='row'>
                    <div className='col-5 px-0 pe-lg-0 pe-2 d-sm-block d-none'>
                        <div className='bg-da4 h-100 border-radius-login'>
                            <div className='position-relative  height565px'>
                                <div className='position-absulate-for-content-login'>
                                    <h4 className='text-white fw-bold fs-3 text-center pb-2'>Welcome Back!</h4>
                                    <p className='text-white fw-normal px-4'>Lorem Ipsum has been the industry's standard dummy
                                        text ever since the 1500s, when an unknown printer
                                        took a galley.
                                    </p>
                                </div>
                                <div className='position-absulate-for-loginsmall'>
                                    <img src='./image/loginsmall.png' alt='' width="100%" />
                                </div>
                                <div className='position-absulate-for-loginsmall2'>
                                    <img src='./image/loginsmall2.png' className='mloginsmall2' alt='' width="160px" />
                                </div>
                                <div className='position-absulate-for-loginsmall3'>
                                    <img src='./image/loginsmall3.png' className='rotated-image mloginsmall3' alt='' width="400px" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className='col-sm-7 col px-0 position-relative'>
                        <div className=''>
                            <div className='d-flex flex-column justify-content-center align-items-center padding-login-page-input'>
                                <div>
                                    <h4 className='fs-32px-in-login-title fw-bold pb-3'>Log In To Your Account</h4>
                                    <form>
                                        <div className="input-container my-3">
                                            <label for="email" className='fw-normal fs-6 text-414141 pb-1'>Email</label>
                                            <div className="input-wrapper">
                                                <input className='width-500px-input-field border-radius-input-field border-2 px-3' type="email" id="email" placeholder="Enter email" />
                                                <i className="fas fa-envelope"></i>
                                            </div>
                                        </div>

                                        <div className="input-container">
                                            <label for="password" className='fw-normal fs-6 text-414141 pb-1'>Password</label>
                                            <div className="input-wrapper">
                                                <input type={showPassword ? "text" : "password"} className='width-500px-input-field border-radius-input-field border-2 px-3' id="password" placeholder="Enter password" />
                                                <i className={`fas ${showPassword ? 'fa-eye' : 'fa-eye-slash'}`} onClick={togglePasswordVisibility}
                                                    style={{ cursor: 'pointer' }}></i>
                                            </div>
                                        </div>

                                        <div className="form-footer d-sm-flex text-center justify-content-lg-between py-4 align-items-center">
                                            <div className="form-check d-flex justify-content-center">
                                                <input type="checkbox" id="remember" className="form-check-input" />
                                                <label for="remember" className='ps-2 fs-6 fw-normal text-2121 pe-lg-0 pe-3 d-sm-flex d-block'>Remember Me</label>
                                            </div>
                                            <Link className="forgot-password text-e05 text-decoration-none ">Forgot Password?</Link>
                                        </div>

                                        <div>
                                            <button className='w-100 bg-da4 text-white border-0 border-radius-input-field change-button-width-992 py-2 fs-6 fw-bold'>Login</button>
                                        </div>
                                    </form>
                                    <div className='pt-3'>
                                        <div className='text-center'>
                                            <p className='fs-normal fs-5 text-2121'>Have an Account?
                                                <span>
                                                    <Link to={"/Signup"} className='d-inline-block text-e05 text-decoration-none ps-2'>Sign up</Link>
                                                </span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className='position-absulate-loginsmall4'>
                                <img src='./image/loginsmall4.png' className='mloginsmall4' width="100%" alt='' />
                            </div>

                            <div className='position-absulate-loginsmall5'>
                                <img src='./image/loginsmall5.png' width="100%" height="280" alt='' />
                            </div>

                            <div className='position-absulate-loginsmall6'>
                                <img src='./image/loginsmall6.png' width="100%" height="280" alt='' />
                            </div>

                            <div className='position-absulate-loginsmall7'>
                                <img src='./image/loginsmall7.png' width="100%" alt='' />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Login;
