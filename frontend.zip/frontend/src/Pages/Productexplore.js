import React from 'react';
import { Link } from 'react-router-dom';
import Rating from '@mui/material/Rating';
import Stack from '@mui/material/Stack';
import Footer from '../Component/Footer';

import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';

function Productexplore() {
    const [open, setOpen] = React.useState(false);
    const [scroll, setScroll] = React.useState('paper');

    const handleClickOpen = (scrollType) => () => {
        setOpen(true);
        setScroll(scrollType);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const descriptionElementRef = React.useRef(null);
    React.useEffect(() => {
        if (open) {
            const { current: descriptionElement } = descriptionElementRef;
            if (descriptionElement !== null) {
                descriptionElement.focus();
            }
        }
    }, [open]);

    const Filterscatogeries = [
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
    ];

    return (
        <main className='poppins'>
            {/* =============pages-wraper-start============= */}
            <section>
                <div className='poppins py-3 pb-md-5 pb-4 '>
                    <div className='container'>
                        <div className='d-flex align-items-center'>
                            <Link to="/" className='link text-2121'><h6 className='m-0  fw-normal'>Home</h6></Link>
                            <i className="fa-solid fa-angle-right py-1 px-3 fs-18 text-2121"></i>
                            <Link to="/Desktop" className='link text-2121'><h6 className='m-0  fw-normal'>Cooker</h6></Link>
                            <i className="fa-solid fa-angle-right py-1 px-3 fs-18 text-2121"></i>
                            <Link className='link text-2121'><h6 className='m-0  fw-normal'>Cooker</h6></Link>
                        </div>
                    </div>
                </div>
            </section>
            {/* =============pages-wraper-start============= */}

            {/* ===========categories======== */}
            <section>
                <div className='container'>
                    <div className='row'>
                        <div className='d-md-none d-block pb-2'>
                            <React.Fragment>
                                <Button className='text-start btn bg-da44 ' onClick={handleClickOpen('paper')}>Filters<i className="ps-2 align-middle fa-solid fa-filter"></i></Button>
                                <Dialog
                                    open={open}
                                    onClose={handleClose}
                                    scroll={scroll}
                                    aria-labelledby="scroll-dialog-title"
                                    aria-describedby="scroll-dialog-description"
                                >
                                    <DialogContent dividers={scroll === 'paper'}>
                                        <DialogContentText
                                            id="scroll-dialog-description"
                                            ref={descriptionElementRef}
                                            tabIndex={-1}
                                        >
                                            <div className='poppins'>
                                                <h5 className='fw-bold fs-5 pb-md-0 pb-3'>Filters<i className="ps-2 align-middle fa-solid fa-filter"></i></h5>
                                                <div className='border border-1 border-black rounded-3 py-3'>
                                                    <div className='bg-da4 mx-1 rounded-3'>
                                                        <h6 className='fw-bold fs-18px-in-filter-title text-white py-2 mb-3 ps-5'>Material</h6>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>Stainless Steel</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>Polished Stainless Steel</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>Non Stick</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>Cast Lron</label>
                                                    </div>
                                                    <div className='border-bottom border-black border-1 pt-3'></div>

                                                    <div className='bg-da4 mx-1 rounded-3 mt-3'>
                                                        <h6 className='fw-bold fs-18px-in-filter-title text-white py-2 mb-3 ps-5'>Price</h6>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                                    </div>
                                                    <div className='border-bottom border-black border-1 pt-3'></div>

                                                    <div className='bg-da4 mx-1 rounded-3 mt-3'>
                                                        <h6 className='fw-bold fs-18px-in-filter-title text-white py-2 mb-3 ps-5'>Color</h6>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>Black</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>Silver</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>Teal</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>Blue</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>Grey</label>
                                                    </div>
                                                    <div className='border-bottom border-black border-1 pt-3'></div>


                                                    <div className='bg-da4 mx-1 rounded-3 mt-3'>
                                                        <h6 className='fw-bold fs-18px-in-filter-title text-white py-2 mb-3 ps-5'>Discount Range</h6>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>10% And Above</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>20% And Above</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>30% And Above</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>40% And Above</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>50% And Above</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </DialogContentText>
                                    </DialogContent>
                                    <DialogActions>
                                        <Button onClick={handleClose}>Cancel</Button>
                                        <Button onClick={handleClose}>Apply</Button>
                                    </DialogActions>
                                </Dialog>
                            </React.Fragment>
                        </div>


                        <div className='col-md-4 d-md-block d-none'>
                            <div>
                                <h5 className='fw-bold fs-5'>Filters<i className="ps-2 align-middle fa-solid fa-filter"></i></h5>
                                <div className='border border-1 border-black rounded-3 py-3'>
                                    <div className='bg-da4 mx-1 rounded-3'>
                                        <h6 className='fw-bold fs-18 text-white py-2 mb-3 ps-5'>Material</h6>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>Stainless Steel</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>Polished Stainless Steel</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>Non Stick</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>Cast Lron</label>
                                    </div>
                                    <div className='border-bottom border-black border-1 pt-3'></div>

                                    <div className='bg-da4 mx-1 rounded-3 mt-3'>
                                        <h6 className='fw-bold fs-18 text-white py-2 mb-3 ps-5'>Price</h6>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                    </div>
                                    <div className='border-bottom border-black border-1 pt-3'></div>

                                    <div className='bg-da4 mx-1 rounded-3 mt-3'>
                                        <h6 className='fw-bold fs-18 text-white py-2 mb-3 ps-5'>Color</h6>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>Black</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>Silver</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>Teal</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>Blue</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>Grey</label>
                                    </div>
                                    <div className='border-bottom border-black border-1 pt-3'></div>


                                    <div className='bg-da4 mx-1 rounded-3 mt-3'>
                                        <h6 className='fw-bold fs-18 text-white py-2 mb-3 ps-5'>Discount Range</h6>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>10% And Above</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>20% And Above</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>30% And Above</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>40% And Above</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>50% And Above</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className='col-md-8'>
                            <div className='container'>
                                <div className='row'>
                                    {Filterscatogeries.map((product, index) => (
                                        <div key={index} className='col-xxl-3 col-lg-4 col-sm-6 px-sm-2 px-0 py-2'>
                                            <div className='bg-medium-pink rounded-3 p-3'>
                                                <div className='position-relative '>
                                                    <img src={product.image} width="100%" className='rounded-3 pimage-size' alt={product.name} />
                                                    <div className='position-absolute-newarrival-icon'>
                                                        <i className="fa-regular text-light fs-4 fa-heart"></i>
                                                    </div>
                                                </div>
                                                <div>
                                                    <h6 className='m-0 fw-bold fs-14 pt-2'>{product.name}</h6>
                                                    <Stack spacing={1} className='py-1'>
                                                        <Rating name="size-extra-small" defaultValue={2} size="small" />
                                                    </Stack>
                                                    <div>
                                                        <p className='fw-normal fs-14 text-e05'>Free Delivery</p>
                                                    </div>
                                                    <div className='d-flex align-items-center justify-content-md-between'>
                                                        <h6 className='mb-0 fw-bold fs-14'>{product.rs}</h6>
                                                        {product.price && <div className="px-1 text-6161"><del className='px-md-0 px-2'>{product.price}</del></div>}
                                                        <div className="product-discount fs-10 px-2 py-1">{product.discount}</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <Footer />
        </main>
    )
}

export default Productexplore;
