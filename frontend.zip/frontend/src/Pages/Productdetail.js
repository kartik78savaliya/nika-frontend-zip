import React, { useState } from "react";
import { Link } from "react-router-dom";
import Rating from "@mui/material/Rating";
import Stack from "@mui/material/Stack";
import Productrelated from "../Component/Productreleteditems";
import Footer from "../Component/Footer";

function Productdetail() {
  const [videoSrc, setVideoSrc] = useState(
    "https://www.youtube.com/embed/tgbNymZ7vqY"
  );
  const handleImageClick = (videoSrc) => {
    setVideoSrc(videoSrc);
  };
  return (
    <main className="poppins">
      {/* =============pages-wraper-start============= */}
      <section>
        <div className="poppins py-3 pb-md-5 pb-4 ">
          <div className="container">
            <div className="d-flex align-items-center">
              <Link to="/" className="link text-2121">
                <h6 className="m-0  fw-normal">Home</h6>
              </Link>
              <i className="fa-solid fa-angle-right py-1 px-3 fs-18 text-2121"></i>
              <Link className="link text-2121">
                <h6 className="m-0  fw-normal">Cooker</h6>
              </Link>
              <i className="fa-solid fa-angle-right py-1 px-3 fs-18 text-2121"></i>
              <Link className="link text-2121">
                <h6 className="m-0  fw-normal">Cooker</h6>
              </Link>
            </div>
          </div>
        </div>
      </section>
      {/* =============pages-wraper-start============= */}

      {/* ============Product-cart-start========== */}
      <div className="poppins">
        <div className="container">
          <div className="row">
            <div className="col-lg-5">
              <div>
                {/* <img src='./image/productdetail.jpg' width="100%" className='rounded-3' /> */}
                <iframe
                  width="100%"
                  title=""
                  height="300px"
                  className="rounded-3 iframe-height"
                  src={videoSrc}
                ></iframe>
              </div>
              <div className="d-flex align-items-center py-3">
                <div className="">
                  <img
                    className="rounded-3"
                    src="./image/productdetail.jpg"
                    alt="Video 1"
                    width="100%"
                    height="100%"
                    onClick={() =>
                      handleImageClick(
                        "https://www.youtube.com/embed/kpHBxLqkikw"
                      )
                    }
                  />
                </div>
                <div className="px-3 text-center">
                  <img
                    className="rounded-3"
                    src="./image/productdetail.jpg"
                    alt="Video 2"
                    width="100%"
                    height="100%"
                    onClick={() =>
                      handleImageClick(
                        "https://www.youtube.com/embed/fhxPMHKoQvo"
                      )
                    }
                  />
                </div>
                <div className=" text-end">
                  <img
                    className="rounded-3"
                    src="./image/productdetail.jpg"
                    alt="Video 3"
                    width="100%"
                    height="100%"
                    onClick={() =>
                      handleImageClick(
                        "https://www.youtube.com/embed/1nNz_58fEb4"
                      )
                    }
                  />
                </div>
              </div>
              <br></br>
              <h4 className="text-newtheme-blue fw-bold fs-3">Select Branch</h4>
              <button
                style={{ borderColor: "#114b63" }}
                className="p-4 m-2 border-2 rounded-4 bg-transparent"
              >
                Katargam branch
                <p className="text-success">in stock</p>
              </button>

              <button style={{ borderColor: "#114b63" }} className="p-4 m-2 border-2 rounded-4 bg-transparent">
                Yogichawk branch <p className="text-danger">out of stock</p>
              </button>
            </div>
            <div className="col-lg-7 py-lg-0 pt-sm-3 pt-2">
              <h3 className="fw-bold text-newtheme-blue fs-3">Products Name</h3>
              <Stack spacing={1}>
                <Rating name="size-medium" defaultValue={2} />
              </Stack>
              <div className="d-flex align-items-center">
                <h6 className="fw-bold fs-3 text-newtheme-blue mb-0 fs-small-cart-price">
                  ₹ 1000
                </h6>
                <h6 className="fs-3 fw-normal px-4 py-2 mb-0 fs-small-cart-price">
                  ₹ 1500
                </h6>
                <h6 className="fw-bold bg-da4 text-white py-2 mb-0 px-sm-4 px-3 rounded-3 fs-small-cart-price">
                  18% off
                </h6>
              </div>

              <div className="border-black pt-sm-1 pt-2 border-bottom"></div>
              <div>
                <h6 className="fw-bold text-newtheme-blue fs-5 py-2">
                  Select Material
                </h6>
                <div className="d-flex align-items-center pb-2">
                  <input type="checkbox" />
                  <label className="fw-normal text-2121 ps-2 fs-6">
                    Stainless Steel
                  </label>
                </div>
                <div className="d-flex align-items-center pb-2">
                  <input type="checkbox" />
                  <label className="fw-normal text-2121 ps-2 fs-6">
                    Polished Stainless Steel
                  </label>
                </div>
                <div className="d-flex align-items-center pb-2">
                  <input type="checkbox" />
                  <label className="fw-normal text-2121 ps-2 fs-6">
                    Non Stick
                  </label>
                </div>
                <div className="d-flex align-items-center pb-2">
                  <input type="checkbox" />
                  <label className="fw-normal text-2121 ps-2 fs-6">
                    Cast Lron
                  </label>
                </div>
              </div>

              <div className="pt-3">
                <Link to="/Cart">
                  <button className="bg-da4 text-white border-0 py-2 fw-bold px-sm-5 px-4 rounded-3">
                    <i className="pe-2 fa-solid fa-cart-shopping"></i>Add To
                    Cart
                  </button>
                </Link>
              </div>

              <div>
                <h6 className="fw-bold text-newtheme-blue fs-5 py-2">
                  About This Item
                </h6>
                <div className="d-flex">
                  <div className="svg-circle mt-2"></div>
                  <p className="fs-5 line-height-30px ps-3">
                    Lorem Ipsum has been the industry's standard dummy text ever
                    since the 1500s, when an unknown printer took a galley of
                    type and scrambled it to make a type specimen book.
                  </p>
                </div>
                <div className="d-flex py-3">
                  <div className="svg-circle mt-2"></div>
                  <p className="fs-5 line-height-30px ps-3">
                    Lorem Ipsum has been the industry's standard dummy text ever
                    since the 1500s, when an unknown printer took a galley of
                    type and scrambled it to make a type specimen book.
                  </p>
                </div>
                <div className="d-flex">
                  <div className="svg-circle mt-2"></div>
                  <p className="fs-5 line-height-30px ps-3">
                    Lorem Ipsum has been the industry's standard dummy text ever
                    since the 1500s, when an unknown printer took a galley of
                    type and scrambled it to make a type specimen book.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ===========products Description to this item-start============= */}
      <div className="poppins">
        <div className="pt-4 pb-sm-5 pb-3">
          <div className="pb-3">
            <div className="container">
              <div className="row">
                <div className="d-flex align-items-center justify-content-between px-3">
                  <h4 className="font-size-32px-product-title text-newtheme-blue my-0">
                    Products Description
                  </h4>
                </div>
                <div className="py-4 fs-5">
                  <p>
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen book. It has survived not only five centuries,
                    but also the leap into electronic typesetting, remaining
                    essentially unchanged. It was popularised in the 1960s with
                    the release of Letraset sheets containing Lorem Ipsum
                    passages, and more recently with desktop publishing software
                    like Aldus PageMaker including versions of Lorem Ipsum.
                  </p>
                  <br></br>
                  <p>
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen book. It has survived not only five centuries,
                    but also the leap into electronic typesetting, remaining
                    essentially unchanged. It was popularised in the 1960s with
                    the release of Letraset sheets containing Lorem Ipsum
                    passages, and more recently with desktop publishing software
                    like Aldus PageMaker including versions of Lorem Ipsum.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* ===========products Description to this item-end============= */}

      {/* ===========products related to this item-start============= */}
      <div className="poppins">
        <div className="pt-4 pb-sm-5 pb-3">
          <div className="pb-3">
            <div className="container">
              <div className="row">
                <div className="d-flex align-items-center justify-content-between px-3">
                  <h4 className="font-size-32px-product-title text-newtheme-blue my-0">
                    Products Related To This Item
                  </h4>
                </div>
              </div>
            </div>
          </div>
          <Productrelated />
        </div>
      </div>
      {/* ===========products related to this item-end============= */}

      {/* ===========products related to this item-start============= */}
      <div className="poppins">
        <div className="pt-4 pb-sm-5 pb-3">
          <div className="pb-3">
            <div className="container">
              <div className="row">
                <div className="d-flex align-items-center justify-content-between px-3">
                  <h4 className="font-size-32px-product-title text-newtheme-blue my-0">
                    Products Related To This Item
                  </h4>
                </div>
              </div>
            </div>
          </div>
          <Productrelated />
        </div>
      </div>
      {/* ===========products related to this item-end============= */}

      {/* ====================customer-review-start================ */}
      <div className="poppins pb-sm-5 pb-3">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h4 className="fs-2 fw-bold">Customer Reviews</h4>
              <div className="d-flex align-items-center py-sm-3 pb-2">
                <Stack spacing={1} className="py-1">
                  <Rating
                    name="size-extra-large"
                    defaultValue={2}
                    size="large"
                  />
                </Stack>
                <div className="ps-4">
                  <p className="fw-normal fs-6">4.1 Out Of 5</p>
                </div>
              </div>
              <div className="container">
                <div className="row align-items-center py-2">
                  <div className="col-xxl-1 col-2 px-0">
                    <span className="fw-normal fs-6">5 Star</span>
                  </div>
                  <div className="col-7 px-1">
                    <div className="progress height-24px">
                      <div
                        className="progress-bar bg-da4"
                        role="progressbar"
                        aria-valuenow="25"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      ></div>
                    </div>
                  </div>
                  <div className="col-1 px-0">
                    <p className="fw-normal fs-6">62%</p>
                  </div>
                </div>
                <div className="row align-items-center py-2">
                  <div className="col-xxl-1 col-2 px-0">
                    <span className="fw-normal fs-6">4 Star</span>
                  </div>
                  <div className="col-7 px-1">
                    <div className="progress height-24px">
                      <div
                        className="progress-bar2 bg-da4"
                        role="progressbar"
                        aria-valuenow="25"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      ></div>
                    </div>
                  </div>
                  <div className="col-1 px-0">
                    <p className="fw-normal fs-6">16%</p>
                  </div>
                </div>
                <div className="row align-items-center py-2">
                  <div className="col-xxl-1 col-2 px-0">
                    <span className="fw-normal fs-6">3 Star</span>
                  </div>
                  <div className="col-7 px-1">
                    <div className="progress height-24px">
                      <div
                        className="progress-bar3 bg-da4"
                        role="progressbar"
                        aria-valuenow="25"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      ></div>
                    </div>
                  </div>
                  <div className="col-1 px-0">
                    <p className="fw-normal fs-6">7%</p>
                  </div>
                </div>
                <div className="row align-items-center py-2">
                  <div className="col-xxl-1 col-2 px-0">
                    <span className="fw-normal fs-6">2 Star</span>
                  </div>
                  <div className="col-7 px-1">
                    <div className="progress height-24px">
                      <div
                        className="progress-bar4 bg-da4"
                        role="progressbar"
                        aria-valuenow="25"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      ></div>
                    </div>
                  </div>
                  <div className="col-1 px-0">
                    <p className="fw-normal fs-6">3%</p>
                  </div>
                </div>
                <div className="row align-items-center py-2">
                  <div className="col-xxl-1 col-2 px-0">
                    <span className="fw-normal fs-6">1 Star</span>
                  </div>
                  <div className="col-7 px-1">
                    <div className="progress height-24px">
                      <div
                        className="progress-bar5 bg-da4"
                        role="progressbar"
                        aria-valuenow="25"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      ></div>
                    </div>
                  </div>
                  <div className="col-1 px-0">
                    <p className="fw-normal fs-6">12%</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 pt-md-0 pt-3">
              <div>
                <h5 className="fw-bold fs-5 text-newtheme-blue">
                  Top Reviews From India
                </h5>
                <div className="d-flex">
                  <div className="position-relative pe-3">
                    <img src="./image/userlogo-bg.png" />
                    <div className="position-absolute-userlogo">
                      <img src="./image/user-logo.png" width="27px" />
                    </div>
                  </div>
                  <div>
                    <h6 className="fw-bold fs-14 mb-0 text-newtheme-blue">
                      Customers Name
                    </h6>
                    <Stack spacing={1} className="">
                      <Rating
                        name="size-extra-small"
                        defaultValue={2}
                        size="small"
                      />
                    </Stack>
                    <p className="fw-normal fs-14 py-2">
                      Reviewed In India On 22 March 2023
                    </p>
                    <p className="text-ec7 fw-normal pb-2 fs-14">
                      Verified Purchase
                    </p>
                    <p className="fs-5 line-height-30px fw-normal">
                      Lorem Ipsum has been the industry's standard dummy text
                      ever since the 1500s, when an unknown printer took a
                      galley of type and scrambled it to make a type specimen
                      book.
                    </p>
                    <div className="py-3">
                      <img
                        className="rounded-3"
                        src="./image/Helpful.jpg"
                        width="95px"
                      />
                    </div>
                    <div>
                      <Link className="bg-da4 text-white text-decoration-none fw-bold fs-14 px-4 me-3 rounded-2 py-1">
                        Helpful
                      </Link>
                      <Link className="fw-bold fs-14 text-newtheme-blue text-decoration-none border-left  ps-3 py-1">
                        {" "}
                        Report
                      </Link>
                    </div>
                  </div>
                </div>
                <div className="d-flex pt-sm-5 pt-4">
                  <div className="position-relative pe-3">
                    <img src="./image/userlogo-bg.png" />
                    <div className="position-absolute-userlogo">
                      <img src="./image/user-logo.png" width="27px" />
                    </div>
                  </div>
                  <div>
                    <h6 className="fw-bold fs-14 mb-0 text-newtheme-blue">
                      Customers Name
                    </h6>
                    <Stack spacing={1} className="">
                      <Rating
                        name="size-extra-small"
                        defaultValue={2}
                        size="small"
                      />
                    </Stack>
                    <p className="fw-normal fs-14 py-2">
                      Reviewed In India On 22 March 2023
                    </p>
                    <p className="text-ec7 fw-normal pb-2 fs-14">
                      Verified Purchase
                    </p>
                    <p className="fs-5 line-height-30px fw-normal">
                      Lorem Ipsum has been the industry's standard dummy text
                      ever since the 1500s, when an unknown printer took a
                      galley of type and scrambled it to make a type specimen
                      book.
                    </p>
                    <div className="py-3">
                      <img
                        className="rounded-3"
                        src="./image/Helpful.jpg"
                        width="95px"
                      />
                    </div>
                    <div>
                      <Link className="bg-da4 text-white text-decoration-none fw-bold fs-14 px-4 me-3 rounded-2 py-1">
                        Helpful
                      </Link>
                      <Link className="fw-bold fs-14 text-newtheme-blue text-decoration-none border-left ps-3 py-1">
                        {" "}
                        Report
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* ====================customer-review-end================ */}

      {/* ============Product-cart-end========== */}
      <Footer />
    </main>
  );
}

export default Productdetail;
