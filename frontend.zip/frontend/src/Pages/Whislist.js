import React from 'react';
import Mywhislist from '../Component/mywhislist';
import Productcartbox from '../Component/Productcartbox';
import Footer from '../Component/Footer';


function Whislist() {
    return (
        <>
            <main>
                <div className='poppins py-5'>
                    <div className='container'>
                        <div className='row'>
                            <div className='text-center'>
                                <h6 className='fw-bold fs-1'>My Wishlist</h6>
                            </div>
                        </div>
                    </div>

                    <div>
                        <Mywhislist />
                    </div>

                    <div>
                        <Productcartbox />
                    </div>
                </div>
            </main>
            <Footer />
        </>
    )
}

export default Whislist
