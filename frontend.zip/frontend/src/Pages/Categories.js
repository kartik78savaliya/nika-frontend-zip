import React from 'react';
import Rating from '@mui/material/Rating';
import Stack from '@mui/material/Stack';
import Footer from '../Component/Footer';
import { useState } from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import { Link } from 'react-router-dom';


function Categories() {
    const [open, setOpen] = React.useState(false);
    const [scroll, setScroll] = React.useState('paper');

    const handleClickOpen = (scrollType) => () => {
        setOpen(true);
        setScroll(scrollType);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const descriptionElementRef = React.useRef(null);
    React.useEffect(() => {
        if (open) {
            const { current: descriptionElement } = descriptionElementRef;
            if (descriptionElement !== null) {
                descriptionElement.focus();
            }
        }
    }, [open]);


    const Filterscatogeries = [
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
        {
            name: "Products Name",
            rs: "₹ 1000",
            price: "₹ 1500",
            discount: "18% off",
            image: "./image/productarriaval.jpeg"
        },
    ];

    

    const [isCollapsed, setIsCollapsed] = useState(false);

    const toggleCollapse = () => {
        setIsCollapsed(!isCollapsed);
    };
    return (
        <main className='poppins'>
            <div className='container'>
                <div className='py-sm-4 py-3'>
                    <p className='fw-normal text-newtheme-blue fs-5'>Categories</p>
                </div>
            </div>

            {/* ===========categories======== */}
            <section>
                <div className='container'>
                    <div className='row'>
                        <div className='d-md-none d-block pb-2'>
                            <React.Fragment>
                                <Button className='text-start btn bg-da44' onClick={handleClickOpen('paper')}>Filters<i className="ps-2 align-middle fa-solid fa-filter"></i></Button>
                                <Dialog
                                    open={open}
                                    onClose={handleClose}
                                    scroll={scroll}
                                    aria-labelledby="scroll-dialog-title"
                                    aria-describedby="scroll-dialog-description"
                                >
                                    <DialogContent dividers={scroll === 'paper'}>
                                        <DialogContentText
                                            id="scroll-dialog-description"
                                            ref={descriptionElementRef}
                                            tabIndex={-1}
                                        >
                                            <div className='poppins'>
                                                <h5 className='fw-bold fs-5 text-newtheme-blue  pb-md-0 pb-3'>Filters<i className="ps-2 align-middle fa-solid fa-filter"></i></h5>
                                                <div className='border border-1 border-black rounded-3 py-3'>
                                                    <div className='bg-da4 mx-1 rounded-3'>
                                                        <h6 className='fw-bold fs-18 text-white py-2 mb-3 ps-sm-5 ps-3 ms-sm-0 ms-1'>Price</h6>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                                    </div>
                                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                        <input type='checkbox' className='ms-1 me-0' />
                                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                                    </div>
                                                    <div className='border-bottom border-black border-1 pt-3'></div>

                                                    <div className=' position-relative mx-1 mt-2'>
                                                        {/* <button type="button" className="rounded-3 fw-bold fs-18 text-white py-2 mb-3 ps-5 bg-da4 text-white text-start w-100 border-0 line-height-button" data-bs-toggle="collapse" data-bs-target="#demo">Product Type</button> */}
                                                        <button
                                                            type="button"
                                                            className="rounded-3 fw-bold fs-18 text-white py-2 mb-3 ps-sm-5 ps-3 bg-da4 text-white text-start w-100 border-0 line-height-button"
                                                            onClick={toggleCollapse}
                                                            data-bs-toggle="collapse"
                                                            data-bs-target="#demo"
                                                        >
                                                            Product Type
                                                        </button>
                                                        <div className='position-absolute-for-dropdown-filter'>
                                                            <i className={`fas text-white ${isCollapsed ? 'fa-angle-up' : 'fa-angle-down'}`}></i>
                                                        </div>
                                                    </div>

                                                    <div id="demo" className="collapse show">
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Appliances</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Arts And Crafts</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Baby</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Beauty</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Books</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Collectibles</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Electronics</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Fashion</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Fashion Baby</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Fashion Boys</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Fashion Girls</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Fashion Men</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Fashion Women</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Gift Cards</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Health Personal Care</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Home Garden</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Luggage</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Office Products</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Pet Supplies</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Sporting Goods</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Tools</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Toys</label>
                                                        </div>
                                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                                            <input type='checkbox' className='ms-1 me-0' />
                                                            <label className='fw-normal text-2121 ps-3'>Wireless</label>
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>
                                        </DialogContentText>
                                    </DialogContent>
                                    <DialogActions>
                                        <Button onClick={handleClose}>Cancel</Button>
                                        <Button onClick={handleClose}>Apply</Button>
                                    </DialogActions>
                                </Dialog>
                            </React.Fragment>
                        </div>


                        <div className='col-md-4 d-md-block d-none'>
                            <div>
                                <h5 className='fw-bold text-newtheme-blue  fs-5'>Filters<i className="ps-2 align-middle fa-solid fa-filter"></i></h5>
                                <div className='border border-1 border-black rounded-3 py-3'>
                                    <div className='bg-da4 mx-1 rounded-3'>
                                        <h6 className='fw-bold fs-18 text-white py-2 mb-3 ps-5'>Price</h6>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                    </div>
                                    <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                        <input type='checkbox' className='ms-1 me-0' />
                                        <label className='fw-normal text-2121 ps-3'>₹ 1000 to ₹ 5000</label>
                                    </div>
                                    <div className='border-bottom border-black border-1 pt-3'></div>

                                    <div className=' position-relative mx-1 mt-2'>
                                        {/* <button type="button" className="rounded-3 fw-bold fs-18 text-white py-2 mb-3 ps-5 bg-da4 text-white text-start w-100 border-0 line-height-button" data-bs-toggle="collapse" data-bs-target="#demo">Product Type</button> */}
                                        <button
                                            type="button"
                                            className="rounded-3 fw-bold fs-18 text-white py-2 mb-3 ps-5 bg-da4 text-white text-start w-100 border-0 line-height-button"
                                            onClick={toggleCollapse}
                                            data-bs-toggle="collapse"
                                            data-bs-target="#demo"
                                        >
                                            Product Type
                                        </button>
                                        <div className='position-absolute-for-dropdown-filter'>
                                            <i className={`fas text-white ${isCollapsed ? 'fa-angle-up' : 'fa-angle-down'}`}></i>
                                        </div>
                                    </div>

                                    <div id="demo" className="collapse show">
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Appliances</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Arts And Crafts</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Baby</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Beauty</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Books</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Collectibles</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Electronics</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Fashion</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Fashion Baby</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Fashion Boys</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Fashion Girls</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Fashion Men</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Fashion Women</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Gift Cards</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Health Personal Care</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Home Garden</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Luggage</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Office Products</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Pet Supplies</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Sporting Goods</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Tools</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Toys</label>
                                        </div>
                                        <div className='ps-lg-5 ps-3 d-flex align-items-center pt-3'>
                                            <input type='checkbox' className='ms-1 me-0' />
                                            <label className='fw-normal text-2121 ps-3'>Wireless</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className='col-md-8 pt-21px pb-5'>
                            <div className='container'>
                                <div className='row'>
                                    {Filterscatogeries.map((product, index) => (
                                        <div key={index} className='col-xxl-3 col-lg-4 col-sm-6 px-sm-2 px-0 py-2'>
                                            <Link to="/Productdetail" className='link text-black'>
                                                <div className='bg-medium-pink rounded-3 p-3'>
                                                    <div className='position-relative'>
                                                        <img src={product.image} width="100%" className='rounded-3 pimage-size' alt={product.name} />
                                                        <div className='position-absolute-newarrival-icon'>
                                                            <i className="fa-regular text-light fs-4 fa-heart"></i>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <h6 className='m-0 fw-bold fs-14 pt-2'>{product.name}</h6>
                                                        <Stack spacing={1} className='py-1'>
                                                            <Rating name="size-extra-small" defaultValue={2} size="small" />
                                                        </Stack>
                                                        <div>
                                                            <p className='fw-normal fs-14 text-e05'>Free Delivery</p>
                                                        </div>
                                                        <div className='d-flex align-items-center justify-content-md-between'>
                                                            <h6 className='mb-0 fw-bold fs-14'>{product.rs}</h6>
                                                            {product.price && <div className="px-1 text-6161"><del className='px-md-0 px-2'>{product.price}</del></div>}
                                                            <div className="product-discount fs-10 px-2 py-1">{product.discount}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </Link>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <Footer />
        </main>
    )
}

export default Categories;
