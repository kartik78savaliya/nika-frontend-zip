import React from 'react';
import { useLocation } from 'react-router-dom';
import Navbar from "../Component/Navbar";



const Layout = ({ children }) => {
    const location = useLocation();
    const path = location.pathname;

    return (
        <>
            {path !== "/Login" && path !== "/Signup" && <Navbar />}
            {children}
        </>
    );
};

export default Layout;