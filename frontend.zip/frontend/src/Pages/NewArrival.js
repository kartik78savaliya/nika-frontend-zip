import React from 'react';
import { Link } from 'react-router-dom';
import Trendingnewstock from '../Component/Trendingnewstock';
import Footer from '../Component/Footer';

function NewArrival() {
    return (
        <main>
            {/* =============pages-wraper-start============= */}
            <section>
                <div className='poppins py-3 pb-md-5 pb-4 '>
                    <div className='container'>
                        <div className='d-flex align-items-center'>
                            <Link to="/" className='link text-2121'><h6 className='m-0  fw-normal'>Home</h6></Link>
                            <i className="fa-solid fa-angle-right py-1 px-3 fs-18 text-2121"></i>
                            <Link to={"/Desktop"} className='link text-2121'><h6 className='m-0  fw-normal'>Cooker</h6></Link>
                        </div>
                    </div>
                </div>
            </section>
            {/* =============pages-wraper-start============= */}

            {/* ====================New-Arrival-start============== */}
            <div className='poppins'>
                <div className='container'>
                    <div className='max-width-manual-newarriaval'>
                        <h3 className='fs-2 fw-bold text-center text-newtheme-blue mb-3'>New Arrival</h3>
                        <p className='fs-3 fw-normal line-height-pragraph-for-new-arriaval'>Lorem Ipsum has been the industry's standard dummy text ever
                            since the 1500s, when an unknown printer took a galley of type
                            and scrambled it to make a type specimen book.
                        </p>
                    </div>
                </div>
                <div className='container'>
                    <div className='row py-3'>
                        <div className='col-lg-4 py-lg-0 py-3'>
                            <div className='bg-ffeb rounded-3 px-3 py-4'>
                                <p className='fs-5 fw-normal text-newtheme-blue'>Cookware</p>
                                <h4 className='fs-2 fw-bold py-3 mb-0 text-newtheme-blue'>Saucepots And
                                    Casseroles
                                </h4>
                                <p className='fw-normal fs-4'>Lorem Ipsum has been
                                    the industry's standard
                                    dummy text ever since.
                                </p>
                                <div className='pb-2 pt-4'>
                                    <button className='fw-bold py-2 px-5 bg-e05 border-0 rounded-3 text-white'>Shop Now</button>
                                </div>
                            </div>
                        </div>
                        <div className='col-lg-8 py-lg-0 py-3'>
                            <img alt='' src='./image/newarrivalpages.jpeg' width="100%" className='rounded-3 height-newarriaval-image' />
                        </div>
                    </div>
                </div>
            </div>

            <div className='poppins'>
                <div className='container'>
                    <div className='row py-3'>
                        <div className='col-lg-8 py-lg-0 py-3'>
                            <img alt='' src='./image/newarrivalpages.jpeg' width="100%" className='rounded-3 height-newarriaval-image' />
                        </div>
                        <div className='col-lg-4 py-lg-0 py-3'>
                            <div className='bg-ffeb rounded-3 px-3 py-4'>
                                <p className='fs-5 fw-normal text-newtheme-blue'>Cookware</p>
                                <h4 className='fs-2 fw-bold py-3 mb-0 text-newtheme-blue'>Saucepots And
                                    Casseroles
                                </h4>
                                <p className='fw-normal fs-4'>Lorem Ipsum has been
                                    the industry's standard
                                    dummy text ever since.
                                </p>
                                <div className='pb-2 pt-4'>
                                    <button className='fw-bold py-2 px-5 bg-e05 border-0 rounded-3 text-white'>Shop Now</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* ====================New-Arrival-end============== */}

            {/* ==================trending in non stick-start=================== */}
            <div className='poppins'>
                <div className='pt-4 pb-sm-5 pb-3'>
                    <div className='pb-3'>
                        <div className='container'>
                            <div className='row'>
                                <div className='d-flex align-items-center justify-content-between'>
                                    <h4 className='font-size-32px-product-title my-0 text-newtheme-blue'>Trending in Non Stick</h4>
                                    <div>
                                        <button className='bg-da4 product-veiwall-font-size px-2 rounded-2 border-0 text-white py-1'>View All</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <Trendingnewstock />
                </div>
            </div>
            {/* ==================trending in non stick-end=================== */}

            {/* ==================trending in non stick-start=================== */}
            <div className='poppins'>
                <div className='pt-4 pb-sm-5 pb-3'>
                    <div className='pb-3'>
                        <div className='container'>
                            <div className='row'>
                                <div className='d-flex align-items-center justify-content-between'>
                                    <h4 className='font-size-32px-product-title my-0 text-newtheme-blue'>Trending in Non Stick</h4>
                                    <div>
                                        <button className='bg-da4 product-veiwall-font-size px-2 rounded-2 border-0 text-white py-1'>View All</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <Trendingnewstock />
                </div>
            </div>
            {/* ==================trending in non stick-end=================== */}
            <Footer />
        </main>
    )
}

export default NewArrival;
