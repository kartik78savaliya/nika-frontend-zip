import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Footer from '../Component/Footer';

function Cart() {
    const navigate = useNavigate();
    const [quantities, setQuantities] = React.useState({ product1: 1, product2: 1 });
    const pricePerItem = 1000;
    const discountPerItem = 500;

    const handleChange = (product, event) => {
        const newQuantities = { ...quantities, [product]: event.target.value };
        setQuantities(newQuantities);
    };

    const handleRemove = (product) => {
        const newQuantities = { ...quantities };
        delete newQuantities[product];
        setQuantities(newQuantities);
    };

    useEffect(() => {
        if (Object.keys(quantities).length === 0) {
            navigate('/Categories'); 
        }
    }, [quantities, navigate]);

    const totalMRP = pricePerItem * Object.values(quantities).reduce((acc, qty) => acc + qty, 0);
    const totalDiscount = discountPerItem * Object.values(quantities).reduce((acc, qty) => acc + qty, 0);
    const totalAmount = totalMRP - totalDiscount;

    return (
        <>
            <main>
                <div className='poppins pt-sm-5 pt-4'>
                    <div className='container'>
                        <div className='d-flex align-items-center'>
                            <Link to={"/cart"} className='pe-3 text-newtheme-blue text-decoration-none fw-bold font-cart-address'>Cart</Link>
                            <i className="fs-4 px-0 align-middle fa-solid fa-angle-right"></i>
                            <Link to={"/Address"} className='pe-3 text-black text-decoration-none fw-normal font-cart-address'>Address</Link>
                            <i className="fs-4 px-0 align-middle fa-solid fa-angle-right"></i>
                            <Link to="/Payment" className='ps-2 text-black text-decoration-none fw-normal font-cart-address'>Payment</Link>
                        </div>
                    </div>
                </div>

                <div className='poppins py-sm-5 py-4'>
                    <div className='container'>
                        <div className='row align-items-center'>
                            <div className='col-lg-6 pe-xl-5 pe-sm-3'>
                                {Object.keys(quantities).map((product, index) => (
                                    <div className='d-flex border border-black rounded-3 p-sm-3 p-3 mt-4' key={index}>
                                        <div>
                                            <img src='./image/Helpful.jpg' alt='' width="174px" className='rounded-3 width-cart-image' />
                                        </div>
                                        <div className='ps-sm-3 ps-2'>
                                            <h6 className='fw-bold fs-4'>Product Name {index + 1}</h6>
                                            <p className='fw-normal text-2121'>Lorem Ipsum Has Been The Industry's.</p>
                                            <div className='d-flex align-items-center'>
                                                <h6 className='mb-0 fw-bold text-2121 font-discount'>₹ {pricePerItem}</h6>
                                                <p className='fw-normal font-discount px-xl-3 px-2 text-6161'><del>₹ 1500</del></p>
                                                <p className='text-e05 font-off fw-bold'>18% off</p>
                                            </div>

                                            <div className='py-2'>
                                                <Box sx={{ minWidth: 120 }}>
                                                    <FormControl fullWidth>
                                                        <InputLabel id={`demo-simple-select-label-${product}`}>Qty: {quantities[product]}</InputLabel>
                                                        <Select
                                                            labelId={`demo-simple-select-label-${product}`}
                                                            id={`demo-simple-select-${product}`}
                                                            value={quantities[product]}
                                                            label="Qty"
                                                            onChange={(e) => handleChange(product, e)}
                                                        >
                                                            <MenuItem value={1}>1</MenuItem>
                                                            <MenuItem value={2}>2</MenuItem>
                                                            <MenuItem value={3}>3</MenuItem>
                                                        </Select>
                                                    </FormControl>
                                                </Box>
                                            </div>
                                            <div className='text-end'>
                                                <button className='bg-da4 text-white fw-bold rounded-3 border-0 px-3 py-1' onClick={() => handleRemove(product)}>Remove</button>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className='col-lg-6 ps-xl-5 ps-sm-3 pt-lg-0 pt-3'>
                                <div>
                                    <h6 className='fw-bold fs-2'>Price Details</h6>
                                    <div className='d-flex justify-content-between align-items-center py-1'>
                                        <p className='fw-normal font-cart-address'>Total MRP</p>
                                        <p className='fw-normal font-cart-address pe-5'>₹ {totalMRP}</p>
                                    </div>
                                    <div className='d-flex justify-content-between align-items-center py-1'>
                                        <p className='fw-normal font-cart-address'>Discount</p>
                                        <p className='fw-normal font-cart-address pe-5'>₹ {totalDiscount}</p>
                                    </div>
                                    <div className='py-3'>
                                        <div className='border border-bottom border-black'></div>
                                    </div>
                                    <div className='d-flex align-items-center justify-content-between'>
                                        <h6 className='fw-bold fs-4 text-2121 mb-0'>Total Amount</h6>
                                        <p className='fw-normal fs-4 pe-5'>₹ {totalAmount}</p>
                                    </div>
                                    <div className='text-center pt-sm-5 pt-3'>
                                        <Link to="/Address">
                                            <button className='px-5 fw-bold bg-da4 py-2 rounded-3 text-white border-0 '>Place Order</button>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <Footer />
        </>
    );
}

export default Cart;