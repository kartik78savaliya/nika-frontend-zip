import React from 'react';
import { Link } from 'react-router-dom';
import Footer from '../Component/Footer';

function Payment() {
    return (
        <>
            <main className='poppins'>
                <div className='poppins pt-sm-5 pt-4'>
                    <div className='container'>
                        <div className='d-flex align-items-center'>
                            <Link to={"/Cart"} className='pe-3 text-black text-decoration-none font-cart-address'>Cart</Link>
                            <i className="fs-4 px-0 align-middle fa-solid fa-angle-right"></i>
                            <Link to={"/Address"} className='pe-3 text-black  text-decoration-none font-cart-address'>Address</Link>
                            <i className="fs-4 px-0 align-middle fa-solid fa-angle-right"></i>
                            <Link to={"/Payment"} className='ps-2 text-e05 text-decoration-none fw-bold font-cart-address'>Payment</Link>
                        </div>
                    </div>
                </div>

                <div className='py-sm-5 py-4'>
                    <div className='container'>
                        <div className=''>
                            <form className="d-flex flex-column justify-content-center align-items-center">
                                <div className='border border-black rounded-3 w-525px'>
                                    <div className='d-flex align-items-center px-3 py-sm-2 py-1'>
                                        <input type="radio" id="gpay" name="Payment" />
                                        <label for="gpay" className='ps-2 fw-normal font-payment-input text-2121'>G Pay</label><br />
                                    </div>
                                    <div className='d-flex align-items-center px-3 py-sm-2 py-1 border-top border-black'>
                                        <input type="radio" id="ppay" name="Payment" />
                                        <label for="ppay" className='ps-2 fw-normal font-payment-input text-2121'>PhonePe</label><br />
                                    </div>
                                    <div className='d-flex align-items-center px-3 py-sm-2 py-1 border-top border-black'>
                                        <input type="radio" id="Paytm" name="Payment" />
                                        <label for="Paytm" className='ps-2 fw-normal font-payment-input text-2121'>Paytm</label><br />
                                    </div>
                                    <div className='d-flex align-items-center px-3 py-sm-2 py-1 border-top border-black'>
                                        <input type="radio" id="Bupi" name="Payment" />
                                        <label for="Bupi" className='ps-2 fw-normal font-payment-input text-2121'>BHIM UPI</label><br />
                                    </div>
                                </div>
                                <Link to="/Whislist">
                                    <button className='px-sm-5 px-4 py-2 border-0  text-white fw-bold bg-da4 rounded-3 mt-sm-4 mt-3'>Place Order</button>
                                </Link>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
            <Footer />
        </>
    )
}

export default Payment;
