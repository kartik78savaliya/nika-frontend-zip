import React from 'react';
import { Link } from 'react-router-dom';
import Footer from './Component/Footer';

function Address() {
    return (
        <>
            <main className='poppins'>
                <div className='poppins pt-sm-5 pt-4'>
                    <div className='container'>
                        <div className='d-flex align-items-center'>
                            <Link to={"/Cart"} className='pe-3 text-black text-decoration-none  font-cart-address'>Cart</Link>
                            <i className="fs-4 px-0 align-middle fa-solid fa-angle-right"></i>
                            <Link to={"/Address"} className='pe-3 text-e05 text-decoration-none fw-bold font-cart-address'>Address</Link>
                            <i className="fs-4 px-0 align-middle fa-solid fa-angle-right"></i>
                            <Link to="/Payment" className='ps-2 text-black text-decoration-none font-cart-address'>Payment</Link>
                        </div>
                    </div>
                </div>
                <div className='py-sm-5 py-4'>
                    <div className='container'>
                        <div className='row justify-content-center align-items-center'>
                            <form className='col-lg-4 col-sm-6 col'>
                                <div>
                                    <label className='fw-bold fs-4 w-100'>Contact Detail</label>
                                    <input type='text' className='w-100 height-48px rounded-3 py-2 px-2 border-1 py-2 my-2' placeholder='Enter Your Name' />
                                    <input type='text' className='w-100 height-48px rounded-3 py-2 px-2 border-1 py-2 my-2' placeholder='Enter Your Mobile Number' />
                                </div>
                                <div className='py-1'>
                                    <label className='fw-bold fs-4 w-100'>Address</label>
                                    <input type='text' className='w-100 height-48px rounded-3 py-2 px-2 border-1 py-2 my-2' placeholder='Enter Your Address' />
                                </div>
                                <div className='py-1'>
                                    <label className='fw-bold fs-4 w-100'>State</label>
                                    <input type='text' className='w-100 height-48px rounded-3 py-2 px-2 border-1 py-2 my-2' placeholder='Enter Your State' />
                                </div>
                                <div className='text-center pt-2'>
                                    <button className='text-white fw-bold px-5 py-2 rounded-3 bg-da4 border-0'>Add Address</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
            <Footer/>
        </>
    )
}

export default Address;
