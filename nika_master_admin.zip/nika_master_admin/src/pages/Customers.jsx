import React from 'react'

const Customers = () => {
  return (
    <div>customers</div>
  )
}

export default Customers